const mybtn = document.getElementById("bgColor");

mybtn.addEventListener("click", ()=>{
    document.body.style.backgroundColor = "Green"
})